@echo off
if exist "%LOCALAPPDATA%\Programs\Orbit\Orbit.exe" (
  "%LOCALAPPDATA%\Programs\Orbit\Orbit.exe" --diagnose
  exit /b
)
echo Install Orbit with the gift installer first.
pause
exit /b 1
